const mongoose = require("mongoose");

const userSchema = mongoose.Schema({
  FullName: {
    type: String,
  },
  Email: {
    type: String,
  },
  Mobile: {
    type: String,
  },

  Password: {
    type: String,
  },
  city: {
    type: String,
  },
  program: {
    type: String,
  },
  stream: {
    type: String,
  },
});

const UserModel = mongoose.model("gradinningUser", userSchema);
module.exports = {
  UserModel,
};
