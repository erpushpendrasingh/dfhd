const mongoose = require('mongoose')

const Highlight = require('../model/CollegeModel/Highlights')
const Courses = require('../model/CollegeModel/Courses')
const Admission = require('../model/CollegeModel/Admission')
const Cutoff = require('../model/CollegeModel/Cutoff')
const Placement = require('../model/CollegeModel/Placement')
const Scholarship = require('../model/CollegeModel/Scholarship')
const Campus = require('../model/CollegeModel/Campus')
const Award = require('../model/CollegeModel/Awards')
const Awards = require('../model/CollegeModel/Awards')
const Seat = require('../model/CollegeModel/Seat')
const Eligibility = require('../model/CollegeModel/Eligibility')


const Collegeschema = new mongoose.Schema({
    name:{
        type:String
    },
    overview:{
        type:Object
    },
    coursesarray:{
        type:Array
    },
    city:{
        type:String
    },
    state:{
        type:String
    },
    fee:{
        type:Array
    },
    Logo:{
        type:String
    },
    Banner:{
        type:String
    },
    url:{
        type:String
    },

    Highlight:[Highlight.schema],
    Courses:[Courses.schema],
    Admission:[Admission.schema],
   
    Cutoff:[Cutoff.schema],
    Placement:[Placement.schema],
    Scholarship:[Scholarship.schema],
    Campus:[Campus.schema],
    Award:[Awards.schema],
    Seat:[Seat.schema],
    Eligibility:[Eligibility.schema]




})

const College = mongoose.model("College",Collegeschema);
module.exports=College;