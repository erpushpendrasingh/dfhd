const mongoose = require("mongoose");

const QuestSchema = mongoose.Schema({
  subject: {
    type: String,
  },

  ques: {
    type: String,
  },

  opt: [
    {
      type: String,
    },
  ],

  correctopt: {
    type: String,
  },
});

const QuestModel = mongoose.model("quest", QuestSchema);

module.exports = {
  QuestModel,
};
