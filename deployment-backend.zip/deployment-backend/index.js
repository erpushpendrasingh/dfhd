const express = require("express");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");
const cors = require("cors");
const OTPRoutes = require("./routes/OTPRoutes");
const { questRouter } = require("./routes/quest");
const { subjectRouter } = require("./routes/getquestbysubject");
const { default: mongoose } = require("mongoose");
const { UserRouter } = require("./routes/User");
const collegeRoutes = require("./routes/getCollegeData");
const routes = require("./routes/Addcollege");
const fetchCollege = require("./routes/Fetchcollege");
const app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());
app.use(cors({ origin: "*" }));
mongoose
 .connect(
  "mongodb+srv://pushpendra:1234@cluster0.edbmizv.mongodb.net/Gradinings?retryWrites=true&w=majority"
  //   "mongodb+srv://pushpendra:1234@cluster0.edbmizv.mongodb.net/examseries?retryWrites=true&w=majority"
 )
 .then(() => {
  console.log("Connected to database MongoDB");
 })
 .catch((error) => {
  console.error("MongoDB connection error:", error);
 });
app.use("/api", UserRouter);
app.use("/api", questRouter);
app.use("/api", subjectRouter);
app.use("/api", OTPRoutes);
app.use("/api", collegeRoutes);
app.use("/api", routes);
app.use("/api", fetchCollege);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
 console.log(`Server is running on port ${PORT}`);
});
