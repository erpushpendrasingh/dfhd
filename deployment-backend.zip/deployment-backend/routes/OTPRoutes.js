const express = require('express')
const router = express.Router()
const axios = require('axios')
const https = require('https');

const instance = axios.create({
    httpsAgent: new https.Agent({  
      rejectUnauthorized: false
    })
  });
router.post('/send-otp', async (req, res) => {
    try {

      console.log(req.body)

      const phoneNumber = req.body.Mobile;


      const otp = Math.floor(1000 + Math.random() * 9000);

      const message = `Dear Student, Please enter your OTP to verify your registration. Your OTP is ${otp} Team GradInnings AFFnADS`;
  
      // Send OTP via Mobizure SMS API

      const username = 'safemaya';
      const apiKey = 'Pmbbo3AsL5IpT2Mm6ISPFSF0tzOMRKyZ';
      const signature = 'AFGRDN';
      const entityType = '1201159491262505429';
      const templateId = '1707171083285482265';
      

      const response = await instance.post(
          `https://api.mobizure.com/pushapi/sendbulkmsg?username=${username}&dest=${phoneNumber}&apikey=${apiKey}&signature=${signature}&msgtype=PM&msgtxt=${message}&entityid=${entityType}&templateid=${templateId}`
      );

      console.log(response.data);
  
      res.status(200).json({ success: true, otp });
    } catch (error) {
      console.error('Error sending OTP:', error);
      res.status(500).json({ success: false, message: error.message });
    }
  });

module.exports = router