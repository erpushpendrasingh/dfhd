// Import necessary modules
const express = require("express");
const College = require("../model/Collegemodel");
const router = express.Router();

router.get("/colleges", async (req, res) => {
 try {
  const colleges = await College.find();
  res.json(colleges);
 } catch (error) {
  console.error("Error fetching colleges:", error);
  res.status(500).send("Internal Server Error");
 }
});

module.exports = router;
