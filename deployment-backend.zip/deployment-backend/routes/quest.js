const express = require("express");
const { QuestModel } = require("../model/questModel");
const questRouter = express.Router();


questRouter.get("/",async(req,res)=>{
    try {
        const getdata = await QuestModel.find()
        res.status(200).json({
            message:"add your data in server",
            getdata
        })
        
    } catch (error) {
        res.status(501).json({
            message:error
        })
    }
})

questRouter.post("/add-questions", async (req, res) => {

  const { subject, ques, opt, correctopt } = req.body;
  try {
    const examData = new QuestModel({
      subject,
      ques,
      opt,
      correctopt,
    });
    await examData.save();
    res.status(201).json({
      message: "Question data uploaded successfully",
      examData,
    });
  } catch (error) {
    console.error("Error:", error); // Log any errors that occur
    res.status(500).json({
      error: "Internal Server Error",
    });
  }
});
module.exports={
    questRouter
}
