const express = require("express")
const { QuestModel } = require("../model/questModel")

const subjectRouter = express.Router()

subjectRouter.get("/subject/:subject",async(req,res)=>{
    try {
        const subject = req.params.subject
        const searchsub = await QuestModel.find({subject})
        if (!searchsub) {
            return res.status(404).json({ message: 'subject not found' });
          }
          res.status(200).json(searchsub);
    } catch (error) {
        res.status(500).json({
            message:error

        })        
    }
})


module.exports={
    subjectRouter
}