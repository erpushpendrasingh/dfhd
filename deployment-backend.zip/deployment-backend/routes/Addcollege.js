const express = require("express");
const router = express.Router();
const addScrapedDataToMongoDB = require("../Controller/College");
const multer = require('multer')
const upload = multer({
    limits: { fileSize: 20 * 1024 * 1024 }, // Limit file size to 10 MB
    // Define how to handle multiple files
    // For multiple files with same name attribute (e.g., multiple <input type="file" name="files">)
    // use upload.array('files') or for different name attributes, use upload.fields([{ name: 'file1' }, { name: 'file2' }])
    storage: multer.memoryStorage() // Store files in memory
  });
 


router.post("/add",upload.fields([{ name: 'logo' }, { name: 'banner' }]),addScrapedDataToMongoDB);

module.exports = router;


// const express = require("express");
// const router = express.Router();
// const ScrappeddataController = require("../controller/College");

// router.post(
//  "/add",
//  ScrappeddataController.uploadFields,
//  ScrappeddataController.addScrapedDataToMongoDB
// );

// module.exports = router;

// // const express = require('express')
// // const router = express.Router();

// // const Scrappeddata = require('../controller/College')

// // router.post('/add',Scrappeddata)

// // module.exports=router;
