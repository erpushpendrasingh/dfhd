const express = require("express");
const bcrypt = require("bcrypt");
const { UserModel } = require("../model/User");
const { ResetTokenModel } = require("../model/ResetTokenModel");
const nodemailer = require("nodemailer");
const UserRouter = express.Router();

UserRouter.get("/user", async (req, res) => {
 try {
  const user = await UserModel.find();
  res.status(201).send({ message: "get user", user: user });
 } catch (error) {
  res.status(401).send({ message: error });
 }
});

UserRouter.post("/user/register", async (req, res) => {
 const { FullName, Email, Mobile, Password, city, program, stream } = req.body;
 console.log(req.body);
 try {
  if (!Email) {
   return res.status(400).json({
    message: "mail id is required",
   });
  }
  // let user = await UserModel.find({ Email });
  // if (user.length > 0) {
  //   return res.status(400).json({
  //     message: "Mail Id already registered",
  //   });
  // }
  bcrypt.hash(Password, 5, async (err, secure_password) => {
   if (err) {
    return res.status(400).json({
     error: err,
     message: "Somthing went wrong",
    });
   } else {
    const user = new UserModel({
     Email,
     Password: secure_password,
     FullName,
     Mobile,
     city,
     program,
     stream,
    });
    await user.save();
    res.status(201).json({
     message: "user register successfully",
     user: user,
    });
   }
  });
 } catch (error) {
  console.error(error);
  res.status(500).json({ error: "Internal Server Error" });
 }
});

UserRouter.post("/user/login", async (req, res) => {
 const { Email, Password } = req.body;
 try {
  const user = await UserModel.find({ Email });

  if (user.length > 0) {
   const hashed_pass = user[0].Password;
   bcrypt.compare(Password, hashed_pass, (err, result) => {
    if (result) {
     res.send({
      message: "Login Successful",
      user: user,
     });
    } else {
     return res.status(400).json({
      error: err,
      message: "Incorrect Password",
     });
    }
   });
  } else {
   res.status(400).json({
    message: "No user exists with this Email",
   });
  }
 } catch (error) {
  res.status(400).json({ error: error.message });
 }
});

// UserRouter.post("/user/forget-password", async (req, res) => {
//  const { Email } = req.body;
//  console.log("Email:", Email);
//  try {
//   const user = await UserModel.findOne({ Email });
//   if (!user) {
//    return res.status(404).json({ message: "User not found" });
//   }

//   const token = Math.random().toString(36).substring(7);

//   const expiryTime = new Date();
//   expiryTime.setHours(expiryTime.getHours() + 1);

//   await new ResetTokenModel({ email: user.Email, token, expiryTime }).save();

//   const transporter = nodemailer.createTransport({
//    host: "smtp.hostinger.com",
//    port: 587,
//    secure: false,
//    auth: {
//     user: "pushpendra@arvmultimedia.com",
//     pass: "Arv@1996",
//    },
//   });

//   const resetLink = `https://api.gradinnings.com/forget-password?token=${token}`;
//   const mailOptions = {
//    from: "pushpendra@arvmultimedia.com",
//    to: "pushpendra@arvmultimedia.com",
//    subject: "Password Reset Request",
//    html: `<p>You have requested to reset your password. Click <a href="${token} ">here </a>to reset your password.</p>`,
//   };

//   transporter.sendMail(mailOptions, (error, info) => {
//    if (error) {
//     console.error(error);
//     return res.status(500).json({ message: "Failed to send reset email" });
//    }
//    console.log("Email sent: " + info.response);
//    res.status(200).json({ message: "Reset email sent" });
//   });
//  } catch (error) {
//   console.error(error);
//   res.status(500).json({ message: "Internal Server Error" });
//  }
// });
UserRouter.post("/user/forget-password", async (req, res) => {
 const { Email } = req.body;
 console.log("Email:", Email);
 try {
  const user = await UserModel.findOne({ Email });
  if (!user) {
   return res.status(404).json({ message: "User not found" });
  }

  const token = Math.random().toString(36).substring(7);

  const expiryTime = new Date();
  expiryTime.setHours(expiryTime.getHours() + 1);

  await new ResetTokenModel({ email: user.Email, token, expiryTime }).save();

  const transporter = nodemailer.createTransport({
   host: "smtp.hostinger.com",
   port: 587,
   secure: false,
   auth: {
    user: "pushpendra@arvmultimedia.com",
    pass: "Arv@1996",
   },
  });

  const resetLink = `http://localhost:3000/forget-password/${token}`; // Change the URL as per your application
  const mailOptions = {
   from: "pushpendra@arvmultimedia.com",
   to: user.Email, // Send the email to the user's email address
   subject: "Password Reset Request",
   html: `<p>You have requested to reset your password. Click <a href="${resetLink}">here</a> to reset your password.</p>`,
  };

  transporter.sendMail(mailOptions, (error, info) => {
   if (error) {
    console.error(error);
    return res.status(500).json({ message: "Failed to send reset email" });
   }
   console.log("Email sent: " + info.response);
   res.status(200).json({ message: "Reset email sent" });
  });
 } catch (error) {
  console.error(error);
  res.status(500).json({ message: "Internal Server Error" });
 }
});

UserRouter.post("/user/reset-password", async (req, res) => {
 const { token, newPassword } = req.body;

 try {
  const resetToken = await ResetTokenModel.findOne({ token });

  if (!resetToken) {
   return res.status(400).json({ message: "Invalid or expired token" });
  }

  if (resetToken.expiryTime < new Date()) {
   await ResetTokenModel.deleteOne({ token });
   return res.status(400).json({ message: "Token has expired" });
  }

  const user = await UserModel.findOne({ Email: resetToken.email });

  if (!user) {
   return res.status(404).json({ message: "User not found" });
  }

  const hashedPassword = await bcrypt.hash(newPassword, 10);

  user.Password = hashedPassword;
  await user.save();

  await ResetTokenModel.deleteOne({ token });

  res.status(200).json({ message: "Password reset successfully" });
 } catch (error) {
  console.error(error);
  res.status(500).json({ message: "Internal Server Error" });
 }
});

module.exports = { UserRouter };
